# Trend Yorum Botu (MIA Reacts)

Bu proje, günlük trend konuları veya kullanıcı tarafından belirlenen başlıkları
kullanarak kısa video yorumları üretmek için tasarlanmıştır. Yazılan metin GPT
tabanlı bir model tarafından oluşturulur, Microsoft Edge TTS servisi
aracılığıyla seslendirilir ve telifsiz bir arka plan videosu üzerine
alttan yazı ile birlikte yerleştirilir.

## Özellikler

- Günlük veya manuel tetikleme ile birden fazla video üretimi.
- Konu listesini `data/topics.txt` dosyasından okur.
- `edge-tts` kullanarak Türkçe doğal ses sentezi.
- FFmpeg ile ses ve arka plan videosunu birleştirerek TikTok/Reels uyumlu
  1080×1920 video çıktıları oluşturur.
- Çıktılar `data/outputs/` klasörüne MP4 formatında kaydedilir.

## Gereksinimler

- Python 3.8 veya üzeri
- [FFmpeg](https://ffmpeg.org/) (sistemde kurulu olmalı)
- OpenAI API anahtarı (ayarlarda `.env` dosyasına yazılacaktır)

## Kurulum

1. Depoyu klonlayın ve dizine gidin:

   ```bash
   git clone https://github.com/yourusername/mia-reacts-centos.git
   cd mia-reacts-centos
   ```

2. Sanal ortam oluşturun ve bağımlılıkları yükleyin:

   ```bash
   python3 -m venv venv
   source venv/bin/activate
   pip install -r requirements.txt
   ```

3. `.env.example` dosyasını `.env` olarak kopyalayın ve gerekli alanları
   doldurun:

   ```bash
   cp .env.example .env
   ```

   `.env` dosyasında en azından `OPENAI_API_KEY` anahtarına kendi OpenAI API
   anahtarınızı yazmalısınız. İsteğe bağlı olarak `VOICE_NAME` ve
   `VIDEO_PER_DAY` değişkenlerini de özelleştirebilirsiniz.

4. `data/background/` klasörüne en az bir telifsiz arka plan videosu (.mp4)
   ekleyin.

5. `data/topics.txt` dosyasındaki her satıra bir konu gelecek şekilde
   doldurun. Örneğin:

   ```
   yapay zeka
   motivasyon
   girişimcilik
   ```

## Kullanım

Aşağıdaki komut bir kerelik çalıştırma örneğidir. Komut çalıştığında
`.env` dosyasındaki `VIDEO_PER_DAY` kadar video oluşturur:

```bash
python main.py
```

Çıktılar `data/outputs/` klasöründe tarih saat damgalı dosyalar olarak
oluşacaktır.

### Günlük Otomatik Çalıştırma

Linux sistemlerde günlük üretim yapmak için cron kullanılabilir. Örneğin
her gün saat 10:00'da çalışması için bir cron girdisi ekleyebilirsiniz:

```
0 10 * * * cd /path/to/mia-reacts-centos && /path/to/venv/bin/python main.py
```

Bu ayar, komutun çıktısını sistem log dosyasına yönlendirir. Dilerseniz
`>>` operatörü ile özel bir log dosyasına da yazdırabilirsiniz.

## Dosya Yapısı

```
mia-reacts-centos/
├── data/
│   ├── audio/          # Geçici ses dosyaları (otomatik oluşturulur)
│   ├── background/     # Arka plan videolarınızı buraya ekleyin
│   ├── outputs/        # Oluşturulan MP4 çıktılar
│   └── topics.txt      # Konu listesi
├── logs/               # İsteğe bağlı log klasörü
├── main.py             # Ana yürütülebilir script
├── requirements.txt    # Python bağımlılıkları
├── .env.example        # Ortam değişkeni örnek dosyası
└── README.md
```

## Notlar

- Proje telif hakkı gerektiren videoları indirmez veya barındırmaz.
  Kendi arka plan videolarınızı sağladığınızdan emin olun.
- Üretilen videoları platformlara (TikTok, Reels, YouTube Shorts vb.)
  yüklemek şu an manuel olarak yapılmalıdır.