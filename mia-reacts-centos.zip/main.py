"""Ana yürütülebilir dosya.

Bu modül, `data/topics.txt` dosyasından rastgele konuları seçerek her biri
yaklaşık 10–15 saniyelik kısa yorum videoları üretir. Metin üretimi için
OpenAI sohbet modeli kullanılır, ses sentezi için `edge_tts` kütüphanesi
kullanılır ve FFmpeg aracılığıyla seçilen bir arka plan videosu ile birleştirilir.

Ön koşullar:
* `.env` dosyasında geçerli bir `OPENAI_API_KEY` bulunmalıdır.
* `data/background/` içinde en az bir `.mp4` video olmalıdır.
* Sisteminizde `ffmpeg` kurulu ve PATH değişkenine eklenmiş olmalıdır.
"""

from __future__ import annotations

import asyncio
import datetime
import os
import random
import subprocess
from pathlib import Path

from dotenv import load_dotenv
import openai
import edge_tts


# .env dosyasını yükle
load_dotenv()


OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")
if not OPENAI_API_KEY:
    raise RuntimeError(
        "OPENAI_API_KEY environment variable is missing. Please set it in your .env file."
    )

# Ses karakterini ve günlük üretilecek video sayısını ortamdan okuyun
VOICE_NAME: str = os.getenv("VOICE_NAME", "tr-TR-ArdaNeural")
VIDEO_PER_DAY: int = int(os.getenv("VIDEO_PER_DAY", "3"))

client = openai.OpenAI(api_key=OPENAI_API_KEY)

# Dizinler
DATA_DIR = Path("data")
AUDIO_DIR = DATA_DIR / "audio"
BG_DIR = DATA_DIR / "background"
OUTPUT_DIR = DATA_DIR / "outputs"
TOPICS_FILE = DATA_DIR / "topics.txt"


def ensure_directories() -> None:
    """Gerekli klasörlerin var olduğundan emin olun."""
    for directory in [AUDIO_DIR, BG_DIR, OUTPUT_DIR]:
        directory.mkdir(parents=True, exist_ok=True)


async def tts_generate(text: str, filename: str) -> None:
    """`edge-tts` ile metni sese çevirip dosyaya kaydeder."""
    communicate = edge_tts.Communicate(text, VOICE_NAME)
    await communicate.save(filename)


def generate_script(topic: str) -> str:
    """Belirli bir konu hakkında kısa bir yorum metni üretir."""
    system_prompt = (
        "Enerjik, bilgilendirici ve kısa Türkçe video yorumu üret. "
        "İzleyiciye soru sorarak bitir."
    )
    user_prompt = (
        f"Güncel konu: {topic}\n"
        "Yaklaşık iki cümlelik, 10–15 saniyelik video metni yaz. "
        "Telif ve kişisel veri içermesin."
    )
    response = client.chat.completions.create(
        model="gpt-3.5-turbo-1106",
        messages=[
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_prompt},
        ],
        max_tokens=120,
        temperature=0.8,
    )
    return response.choices[0].message.content.strip()


def compose_video(audio_path: str, bg_path: str, output_path: str) -> None:
    """Ses ve arka plan videosunu FFmpeg kullanarak birleştirir."""
    cmd = [
        "ffmpeg",
        "-y",
        "-i",
        bg_path,
        "-i",
        audio_path,
        "-vf",
        (
            "scale=1080:1920:force_original_aspect_ratio=decrease," +
            "pad=1080:1920:(ow-iw)/2:(oh-ih)/2,setsar=1"
        ),
        "-map",
        "0:v",
        "-map",
        "1:a",
        "-shortest",
        "-c:v",
        "libx264",
        "-crf",
        "23",
        "-preset",
        "fast",
        "-c:a",
        "aac",
        "-b:a",
        "192k",
        output_path,
    ]
    subprocess.run(cmd, check=True)


async def create_videos() -> None:
    """Konu listesinden seçerek belirtilen sayıda video oluşturur."""
    # Gerekli klasörleri hazırla
    ensure_directories()
    # Konuları oku
    if not TOPICS_FILE.exists():
        print(f"Konu dosyası bulunamadı: {TOPICS_FILE}")
        return
    with TOPICS_FILE.open("r", encoding="utf-8") as f:
        topics = [line.strip() for line in f if line.strip()]
    if not topics:
        print(f"Konu dosyasında hiç satır yok: {TOPICS_FILE}")
        return
    # Arka plan dosyalarını listele
    bg_files = [str(p) for p in BG_DIR.glob("*.mp4")]
    if not bg_files:
        print(f"Lütfen {BG_DIR} klasörüne en az bir arka plan videosu (.mp4) ekleyin.")
        return
    for i in range(VIDEO_PER_DAY):
        topic = random.choice(topics)
        print(f"[{i + 1}/{VIDEO_PER_DAY}] konu: {topic}")
        # Metin ve ses üret
        script = generate_script(topic)
        timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
        audio_file = AUDIO_DIR / f"{timestamp}.mp3"
        await tts_generate(script, str(audio_file))
        bg_path = random.choice(bg_files)
        output_file = OUTPUT_DIR / f"{timestamp}.mp4"
        compose_video(str(audio_file), bg_path, str(output_file))
        print(f"Oluşturulan video: {output_file}")


def main() -> None:
    try:
        asyncio.run(create_videos())
    except KeyboardInterrupt:
        print("İşlem kullanıcı tarafından durduruldu.")


if __name__ == "__main__":
    main()